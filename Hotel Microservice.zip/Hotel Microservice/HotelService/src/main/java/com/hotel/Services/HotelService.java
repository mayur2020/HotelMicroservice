package com.hotel.Services;

import com.hotel.Entity.Hotel;

import java.util.List;

public interface HotelService {

    //create hotel service
    Hotel saveHotel(Hotel hotel);

    //get all hotel service
    List<Hotel> getAllHotels();

    //get hotels by Id
    Hotel getHotelById(String hotelid);
}
