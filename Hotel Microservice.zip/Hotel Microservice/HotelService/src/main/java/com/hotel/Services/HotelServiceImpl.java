package com.hotel.Services;

import com.hotel.Entity.Hotel;
import com.hotel.Exception.ResourceNotFoundException;
import com.hotel.Repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class HotelServiceImpl implements HotelService{

    @Autowired
    public HotelRepository hotelRepo;

    @Override
    public Hotel saveHotel(Hotel hotel) {
        String randomHotelId = UUID.randomUUID().toString();
        hotel.setHotelid(randomHotelId);
        System.out.println(hotel);
        return hotelRepo.save(hotel);
    }

    @Override
    public List<Hotel> getAllHotels() {
        return hotelRepo.findAll();
    }

    @Override
    public Hotel getHotelById(String hotelid) {
        return hotelRepo.findById(hotelid).orElseThrow(() -> new ResourceNotFoundException("Given id not found on server..!!"));
    }
}
