package com.hotel.Controller;

import com.hotel.Entity.Hotel;
import com.hotel.Services.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotels")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    //create hotel
    @PostMapping()
    public ResponseEntity<Hotel> createHotel(@RequestBody Hotel hotel)
    {
        System.out.println(hotel);
        Hotel hotel1 = hotelService.saveHotel(hotel);
        return ResponseEntity.status(HttpStatus.CREATED).body(hotel1);
    }

    //get all hotel
    @GetMapping()
    public ResponseEntity<List<Hotel>> getAllHotels()
    {
        return ResponseEntity.ok(hotelService.getAllHotels());
    }

    //get hotel by Id
    @GetMapping("/{hotelId}")
    public ResponseEntity<Hotel> getHotelsById(@PathVariable String hotelid)
    {
        return ResponseEntity.status(HttpStatus.OK).body(hotelService.getHotelById(hotelid));
    }
}
