package com.rating.Entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Table(name = "Rating")
public class Rating {

    @Id
    private String ratingId;
    private String hotelId;
    private String userId;
    private String rating;
    private String feedback;

}
