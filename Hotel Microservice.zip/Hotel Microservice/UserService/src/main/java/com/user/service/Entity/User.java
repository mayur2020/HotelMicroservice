package com.user.service.Entity;

import lombok.*;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name="micro_user")
public class User {
    @Id
    @Column(name = "Id")
    public String userId;

    @Column(name = "username", length = 20)
    public String name;
    public String email;
    public String about;

    @Transient
    private List<Rating> ratings = new ArrayList<>();
}
