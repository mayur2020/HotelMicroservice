package com.hotel.Exception;

public class ResourceNotFoundException extends RuntimeException{

    public ResourceNotFoundException(String exep){
        super(exep);
    }

    ResourceNotFoundException(){
        super("Resource not found !!!");
    }
}
