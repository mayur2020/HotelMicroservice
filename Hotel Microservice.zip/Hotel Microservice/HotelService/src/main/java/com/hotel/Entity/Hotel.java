package com.hotel.Entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@ToString
@Table(name = "hotels")
public class Hotel {
    @Id
    public String hotelid;
    public String name;
    public String location;
    public String about;


}
