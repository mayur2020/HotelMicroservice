package com.rating.Services;

import com.rating.Entity.Rating;
import org.springframework.stereotype.Service;

import java.util.List;

public interface RatingService{

    //create rating
    Rating create(Rating rating);

    //getAllRatings
    List<Rating> getAllRating();

    //get Ratings by user id
    List<Rating> getRatingByUserId(String userId);

    //get Rating by hotel id
    List<Rating> getRatingByHotelId(String hotelId);
}
